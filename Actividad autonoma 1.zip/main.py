from machine import Pin, Timer
import time

led_rojo = Pin(12, Pin.OUT)
led_amarillo = Pin(26, Pin.OUT)
led_verde = Pin(32, Pin.OUT)

def semaforo(timer):
    led_rojo.value(0)
    led_amarillo.value(0)
    led_verde.value(1)
    time.sleep(5)  

    led_rojo.value(0)
    led_amarillo.value(1)
    led_verde.value(0)
    time.sleep(2)  

    led_rojo.value(1)
    led_amarillo.value(0)
    led_verde.value(0)
    time.sleep(5)  

    led_rojo.value(0)
    led_amarillo.value(0)
    led_verde.value(0)

timer = Timer(0)
timer.init(period=1, mode=Timer.PERIODIC, callback=semaforo)
